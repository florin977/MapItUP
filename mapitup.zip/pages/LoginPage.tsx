import React, { useState } from 'react';
import { UserIcon } from '../components/icons/UserIcon';
import { LockIcon } from '../components/icons/LockIcon';
import { MapIcon } from '../components/icons/MapIcon';
import { ArrowRightIcon } from '../components/icons/ArrowRightIcon';
import MapBackground from '../components/MapBackground';

interface LoginPageProps {
  onAdminLogin: () => void;
  onGuestContinue: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onAdminLogin, onGuestContinue }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock authentication
    if (email === 'admin@campus.edu' && password === 'admin') {
      setError('');
      onAdminLogin();
    } else {
      setError('Invalid credentials. Please try again.');
    }
  };

  return (
    <div className="relative flex items-center justify-center min-h-screen bg-transparent p-4 overflow-hidden">
      <MapBackground />
      <div className="relative z-10 w-full max-w-md animate-fadeInUp bg-white/80 dark:bg-brand-surface/50 backdrop-blur-xl border border-slate-300 dark:border-slate-700 rounded-2xl shadow-2xl p-8 space-y-8">
        <div className="text-center animate-fadeIn" style={{ animationDelay: '0.1s' }}>
          <div className="flex justify-center items-center mb-4">
            <MapIcon className="w-12 h-12 text-violet-500 dark:text-brand-primary" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">MapItUP</h1>
          <p className="text-slate-600 dark:text-brand-text-secondary mt-2">Navigate your campus with ease.</p>
        </div>
        
        <form className="space-y-6 animate-fadeIn" style={{ animationDelay: '0.2s' }} onSubmit={handleLogin}>
          <div>
            <label htmlFor="email" className="text-sm font-medium text-slate-600 dark:text-brand-text-secondary">Admin Email</label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <UserIcon className="w-5 h-5 text-slate-400 dark:text-slate-500" />
              </span>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3 py-2 border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-brand-text-primary rounded-md shadow-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 dark:focus:ring-brand-secondary focus:border-violet-500 dark:focus:border-brand-secondary transition"
                placeholder="admin@campus.edu"
              />
            </div>
          </div>

          <div>
            <label htmlFor="password-admin" className="text-sm font-medium text-slate-600 dark:text-brand-text-secondary">Password</label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <LockIcon className="w-5 h-5 text-slate-400 dark:text-slate-500" />
              </span>
              <input
                id="password-admin"
                name="password-admin"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-3 py-2 border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-brand-text-primary rounded-md shadow-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500 dark:focus:ring-brand-secondary focus:border-violet-500 dark:focus:border-brand-secondary transition"
                placeholder="admin"
              />
            </div>
          </div>

          {error && <p className="text-sm text-red-500 animate-fadeIn">{error}</p>}
          
          <div>
            <button
              type="submit"
              className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-brand-primary to-brand-secondary hover:from-brand-secondary hover:to-brand-primary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-50 dark:focus:ring-offset-brand-surface focus:ring-brand-light transition-all duration-300 transform hover:scale-105"
            >
              Login as Admin
            </button>
          </div>
        </form>

        <div className="relative animate-fadeIn" style={{ animationDelay: '0.3s' }}>
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-300 dark:border-slate-700"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white/80 dark:bg-brand-surface/50 text-slate-500 dark:text-brand-text-secondary">Or</span>
          </div>
        </div>

        <div className="animate-fadeIn" style={{ animationDelay: '0.4s' }}>
          <button
            onClick={onGuestContinue}
            className="w-full flex items-center justify-center py-3 px-4 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm text-sm font-medium text-slate-700 dark:text-brand-text-primary bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-50 dark:focus:ring-offset-brand-surface focus:ring-teal-500 dark:focus:ring-brand-accent transition-transform transform hover:scale-105"
          >
            Continue as Guest
            <ArrowRightIcon className="ml-2 w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;