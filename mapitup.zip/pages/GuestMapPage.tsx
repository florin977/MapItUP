
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MapPinIcon } from '../components/icons/MapPinIcon';
import { SearchIcon } from '../components/icons/SearchIcon';
import { ClockIcon } from '../components/icons/ClockIcon';
import { WalkIcon } from '../components/icons/WalkIcon';
import InteractiveMapView from '../components/InteractiveMapView';
import CampusMapSVG from '../components/CampusMapSVG';
import ThemeSwitcher from '../components/ThemeSwitcher';
import { ArrowLeftIcon } from '../components/icons/ArrowLeftIcon';
import { BuildingIcon } from '../components/icons/BuildingIcon';
import { Building } from '../types';
import ViewTimetableModal from '../components/ViewTimetableModal';

type Floor = 'ground' | 'first' | 'second';

interface GuestMapPageProps {
  onBackToLogin: () => void;
  onSearch: (from: string, to: string) => void;
  customMapSvgs: {
    ground: string | null;
    first: string | null;
    second: string | null;
  };
  buildings: Building[];
}

interface RouteLeg {
  title: string;
  time: number;
  distance: string;
  instructions: string[];
  icon: React.ReactNode;
}

const GuestMapPage: React.FC<GuestMapPageProps> = ({ onBackToLogin, onSearch, customMapSvgs, buildings }) => {
    const [fromPoint, setFromPoint] = useState<Building | null>(null);
    const [toPoint, setToPoint] = useState<Building | null>(null);
    const [routeDetails, setRouteDetails] = useState<{ leg: RouteLeg, totalTime: number, totalDistance: number } | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [is3DView, setIs3DView] = useState(false);
    const [selectedFloor, setSelectedFloor] = useState<Floor>('ground');
    const [selectedBuildingForTimetable, setSelectedBuildingForTimetable] = useState<Building | null>(null);
    const [activeSelection, setActiveSelection] = useState<'from' | 'to' | null>(null);
    const mapContainerRef = useRef<HTMLElement>(null);

    const handleBuildingClick = useCallback((buildingName: string) => {
        const building = buildings.find(b => b.name.toLowerCase() === buildingName.toLowerCase().trim());
        if (!building) return;

        if (activeSelection) {
            if (activeSelection === 'from') {
                setFromPoint(building);
            } else if (activeSelection === 'to') {
                setToPoint(building);
            }
            setActiveSelection(null);
        } else {
            setSelectedBuildingForTimetable(building);
        }
    }, [activeSelection, buildings]);

    useEffect(() => {
        const mapElement = mapContainerRef.current;
        if (!mapElement) return;

        const clickListener = (event: MouseEvent) => {
            const target = event.target as SVGTextElement;
            if (target.tagName.toLowerCase() === 'text' && target.textContent) {
                 if (target.onclick || (target.parentElement && target.parentElement.onclick)) return;
                handleBuildingClick(target.textContent);
            }
        };
        mapElement.addEventListener('click', clickListener);
        return () => {
            mapElement.removeEventListener('click', clickListener);
        };
    }, [customMapSvgs, selectedFloor, handleBuildingClick]);

    const handleFindRoute = (e: React.FormEvent) => {
        e.preventDefault();
        if (!fromPoint || !toPoint) return;
        
        onSearch(fromPoint.name, toPoint.name);
        
        setIsLoading(true);
        setRouteDetails(null);
        
        // Simulate API call for route finding
        setTimeout(() => {
            const routeTime = Math.floor(Math.random() * 8) + 3; // e.g., 3-10 minutes
            const routeDistance = (routeTime * 0.08).toFixed(2);

            const leg: RouteLeg = {
                title: `From ${fromPoint.name} to ${toPoint.name}`,
                time: routeTime,
                distance: `${routeDistance} km`,
                instructions: [
                    `Start at ${fromPoint.name}.`,
                    "Follow the main path towards the central quad.",
                    `Turn left at the fountain.`,
                    `Enter ${toPoint.name} through the main entrance.`
                ],
                icon: <WalkIcon className="w-5 h-5 text-slate-500 dark:text-brand-text-secondary" />
            };

            setRouteDetails({ leg, totalTime: leg.time, totalDistance: parseFloat(leg.distance) });
            setIsLoading(false);
        }, 1500);
    };
    
    const renderMapContent = () => {
        const svgContent = customMapSvgs[selectedFloor];
        if (svgContent) return <g dangerouslySetInnerHTML={{ __html: svgContent }} />;
        if (selectedFloor === 'ground') return <CampusMapSVG onBuildingClick={handleBuildingClick} />;
        return (
            <g>
                <rect x="0" y="0" width="800" height="600" fill="var(--map-bg)" />
                <text x="400" y="300" textAnchor="middle" fontFamily="sans-serif" fontSize="20" fill="var(--map-text)">
                    Map for {selectedFloor} floor is not available.
                </text>
            </g>
        );
    };

    const resetRoute = () => {
        setFromPoint(null);
        setToPoint(null);
        setRouteDetails(null);
        setActiveSelection(null);
    }

  return (
    <div className="flex flex-col h-screen font-sans">
      <header className="bg-white dark:bg-brand-surface shadow-md z-10 border-b border-slate-200 dark:border-slate-800">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <MapPinIcon className="h-8 w-8 text-violet-500 dark:text-brand-primary" />
              <h1 className="ml-3 text-2xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">MapItUP</h1>
            </div>
            <div className="flex items-center space-x-4">
                <button 
                  onClick={onBackToLogin}
                  className="flex items-center text-sm rounded-md px-3 py-1.5 text-slate-600 dark:text-brand-text-secondary hover:bg-slate-100 dark:hover:bg-slate-700/50 hover:text-brand-primary dark:hover:text-brand-light transition-colors"
                  aria-label="Back to Login"
                >
                    <ArrowLeftIcon className="w-4 h-4 mr-2" />
                    <span>Back</span>
                </button>
                <div className="h-6 w-px bg-slate-200 dark:bg-slate-700" />
                <p className="text-slate-600 dark:text-brand-text-secondary">Guest View</p>
                <ThemeSwitcher />
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-96 bg-white dark:bg-brand-surface p-6 overflow-y-auto z-10 flex flex-col border-r border-slate-200 dark:border-slate-800">
          {!routeDetails && !isLoading && (
            <div className="animate-fadeIn">
                <h2 className="text-xl font-semibold text-slate-900 dark:text-brand-text-primary mb-4 tracking-tight">Plan Your Route</h2>
                <form onSubmit={handleFindRoute} className="space-y-4">
                    {/* FROM SECTION */}
                    <div className="space-y-2">
                        <label className="block text-sm font-medium text-slate-700 dark:text-brand-text-secondary">From</label>
                        {!fromPoint ? (
                             <button type="button" onClick={() => setActiveSelection('from')} className={`p-3 w-full border-2 rounded-lg flex items-center justify-center space-x-2 transition-all ${activeSelection === 'from' ? 'bg-violet-50 dark:bg-brand-primary/20 border-brand-primary' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-500'}`}>
                                <BuildingIcon className="w-5 h-5 text-slate-500 dark:text-brand-text-secondary"/>
                                <span className="text-sm font-semibold text-slate-600 dark:text-brand-text-secondary">Select on Map</span>
                            </button>
                        ) : (
                            <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-between">
                                <div className="flex items-center">
                                    <BuildingIcon className="w-5 h-5 text-slate-500 dark:text-brand-text-secondary mr-3"/>
                                    <span className="font-semibold text-slate-800 dark:text-brand-text-primary text-sm truncate">{fromPoint.name}</span>
                                </div>
                                <button type="button" onClick={() => setFromPoint(null)} className="text-sm font-medium text-violet-600 dark:text-brand-secondary hover:underline">Change</button>
                            </div>
                        )}
                        {activeSelection === 'from' && <p className="mt-1 text-xs text-violet-600 dark:text-brand-light animate-fadeIn">Click a building on the map to select a starting point.</p>}
                    </div>
                    {/* TO SECTION */}
                    <div className="space-y-2">
                         <label className="block text-sm font-medium text-slate-700 dark:text-brand-text-secondary">To</label>
                        {!toPoint ? (
                            <button type="button" onClick={() => setActiveSelection('to')} className={`p-3 w-full border-2 rounded-lg flex items-center justify-center space-x-2 transition-all ${activeSelection === 'to' ? 'bg-violet-50 dark:bg-brand-primary/20 border-brand-primary' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-300 dark:border-slate-700 hover:border-slate-400 dark:hover:border-slate-500'}`}>
                                <BuildingIcon className="w-5 h-5 text-slate-500 dark:text-brand-text-secondary"/>
                                <span className="text-sm font-semibold text-slate-600 dark:text-brand-text-secondary">Select on Map</span>
                            </button>
                        ) : (
                            <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-between">
                                <div className="flex items-center">
                                    <BuildingIcon className="w-5 h-5 text-slate-500 dark:text-brand-text-secondary mr-3"/>
                                    <span className="font-semibold text-slate-800 dark:text-brand-text-primary text-sm truncate">{toPoint.name}</span>
                                </div>
                                <button type="button" onClick={() => setToPoint(null)} className="text-sm font-medium text-violet-600 dark:text-brand-secondary hover:underline">Change</button>
                            </div>
                        )}
                        {activeSelection === 'to' && <p className="mt-1 text-xs text-violet-600 dark:text-brand-light animate-fadeIn">Click a building on the map to select a destination.</p>}
                    </div>

                    <button
                    type="submit"
                    disabled={!fromPoint || !toPoint}
                    className="w-full flex justify-center items-center py-2.5 px-4 border border-transparent rounded-md shadow-lg text-sm font-medium text-white bg-gradient-to-r from-brand-primary to-brand-secondary hover:from-brand-secondary hover:to-brand-primary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-brand-surface focus:ring-brand-light disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:from-slate-400 disabled:to-slate-500 transition-all duration-300 transform hover:scale-105 disabled:transform-none"
                    >
                    Find Shortest Route
                    <SearchIcon className="ml-2 w-5 h-5"/>
                    </button>
                </form>
            </div>
          )}
          
          {isLoading && (
                 <div className="flex justify-center items-center h-full">
                    <div className="flex justify-center items-center space-x-2">
                        <div className="w-3 h-3 bg-violet-300 dark:bg-brand-light rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-3 h-3 bg-violet-300 dark:bg-brand-light rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                        <div className="w-3 h-3 bg-violet-300 dark:bg-brand-light rounded-full animate-bounce" style={{animationDelay: '0.3s'}}></div>
                    </div>
                 </div>
            )}
            
            {routeDetails && (
                <div className="animate-fadeIn space-y-6">
                    <div>
                        <h2 className="text-xl font-semibold text-slate-900 dark:text-brand-text-primary tracking-tight">Your Route</h2>
                        <div className="mt-4 bg-slate-100 dark:bg-brand-surface/50 p-4 rounded-lg flex items-center justify-around text-center border border-slate-200 dark:border-slate-700/50">
                            <div>
                                <p className="text-sm text-slate-500 dark:text-brand-text-secondary">Total Time</p>
                                <p className="text-xl font-bold text-brand-primary">{routeDetails.totalTime} <span className="text-base font-medium">min</span></p>
                            </div>
                            <div className="h-10 w-px bg-slate-200 dark:bg-slate-700"></div>
                            <div>
                                <p className="text-sm text-slate-500 dark:text-brand-text-secondary">Total Distance</p>
                                <p className="text-xl font-bold text-brand-primary">{routeDetails.totalDistance.toFixed(1)} <span className="text-base font-medium">km</span></p>
                            </div>
                        </div>
                    </div>
                    
                    <div className="space-y-4">
                        <RouteLegDisplay leg={routeDetails.leg} />
                    </div>
                     <button onClick={resetRoute} className="w-full text-center mt-4 text-sm font-medium text-violet-600 dark:text-brand-secondary hover:underline">Plan a new route</button>
                </div>
            )}

        </aside>

        {/* Map Area */}
        <main ref={mapContainerRef} className="flex-1 bg-slate-200 dark:bg-black relative overflow-hidden">
          <div className="absolute top-4 right-4 z-20 flex items-center space-x-2">
            {!is3DView && (
              <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm p-1 rounded-lg shadow-lg flex items-center space-x-1 animate-fadeIn">
                {(['ground', 'first', 'second'] as const).map((floor) => {
                    const floorLabel = floor === 'ground' ? 'G' : floor === 'first' ? '1' : '2';
                    return (
                        <button
                            key={floor}
                            onClick={() => setSelectedFloor(floor)}
                            className={`px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 w-10 ${
                                selectedFloor === floor ? 'bg-violet-600 dark:bg-brand-primary text-white shadow-lg' : 'text-slate-700 dark:text-brand-text-primary hover:bg-black/10 dark:hover:bg-slate-700/50'
                            }`}
                            aria-label={`View ${floor} floor`}
                            title={`${floor.charAt(0).toUpperCase() + floor.slice(1)} Floor`}
                        >
                            {floorLabel}
                        </button>
                    )
                })}
              </div>
            )}
            <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm p-1 rounded-lg shadow-lg flex items-center">
              <button onClick={() => setIs3DView(false)} className={`px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 ${!is3DView ? 'bg-violet-600 dark:bg-brand-primary text-white shadow-lg' : 'text-slate-700 dark:text-brand-text-primary hover:bg-black/10 dark:hover:bg-slate-700/50'}`} aria-pressed={!is3DView}>2D</button>
              <button onClick={() => setIs3DView(true)} className={`px-3 py-2 text-sm font-semibold rounded-md transition-all duration-200 ${is3DView ? 'bg-violet-600 dark:bg-brand-primary text-white shadow-lg' : 'text-slate-700 dark:text-brand-text-primary hover:bg-black/10 dark:hover:bg-slate-700/50'}`} aria-pressed={is3DView}>3D</button>
            </div>
          </div>
          
          {is3DView ? (
            <div className="w-full h-full flex items-center justify-center animate-fadeIn">
              <div className="text-center">
                <BuildingIcon className="w-16 h-16 text-slate-400 dark:text-slate-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-slate-600 dark:text-slate-400">3D View Placeholder</h3>
                <p className="text-slate-500 dark:text-slate-500">3D model rendering will be implemented here.</p>
              </div>
            </div>
          ) : (
            <InteractiveMapView width="100%" height="100%">
              {renderMapContent()}
            </InteractiveMapView>
          )}

          {selectedBuildingForTimetable && (
            <ViewTimetableModal 
                building={selectedBuildingForTimetable}
                onClose={() => setSelectedBuildingForTimetable(null)}
            />
          )}

        </main>
      </div>
    </div>
  );
};

const RouteLegDisplay: React.FC<{ leg: RouteLeg }> = ({ leg }) => (
    <div className="relative pl-8">
        <div className="absolute top-1 left-0 flex items-center justify-center w-8 h-8">
            <div className="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center">{leg.icon}</div>
        </div>
        <div className="flex justify-between items-center">
            <h3 className="font-semibold text-slate-800 dark:text-brand-text-primary">{leg.title}</h3>
        </div>
        <div className="text-xs text-slate-500 dark:text-brand-text-secondary flex items-center space-x-3 mb-3">
            <div className="flex items-center"><ClockIcon className="w-3 h-3 mr-1"/>{leg.time} min</div>
            <div className="flex items-center"><WalkIcon className="w-3 h-3 mr-1"/>{leg.distance}</div>
        </div>
        <ol className="relative border-l border-slate-300 dark:border-slate-600 ml-4">
            {leg.instructions.map((step, index) => (
                <li key={index} className="mb-4 ml-6">
                    <span className="absolute flex items-center justify-center w-4 h-4 bg-slate-300 dark:bg-slate-600 rounded-full -left-2 ring-4 ring-white dark:ring-brand-surface"></span>
                    <p className="text-sm text-slate-700 dark:text-brand-text-secondary">{step}</p>
                </li>
            ))}
        </ol>
    </div>
);

export default GuestMapPage;
