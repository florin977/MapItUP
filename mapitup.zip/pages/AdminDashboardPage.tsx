



import React, { useState, useRef, useEffect } from 'react';
import { LogoutIcon } from '../components/icons/LogoutIcon';
import { MapIcon } from '../components/icons/MapIcon';
import { UploadIcon } from '../components/icons/UploadIcon';
import { EditIcon } from '../components/icons/EditIcon';
import { PlusIcon } from '../components/icons/PlusIcon';
import ThemeSwitcher from '../components/ThemeSwitcher';
import { DashboardIcon } from '../components/icons/DashboardIcon';
import { DatabaseIcon } from '../components/icons/DatabaseIcon';
import { BuildingIcon } from '../components/icons/BuildingIcon';
import { ChartBarIcon } from '../components/icons/ChartBarIcon';
import { UserGroupIcon } from '../components/icons/UserGroupIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { UploadActivity, Building, Timetable, Day } from '../types';
import InteractiveMapView from '../components/InteractiveMapView';
import CampusMapSVG from '../components/CampusMapSVG';

type Floor = 'ground' | 'first' | 'second';

interface AdminDashboardPageProps {
  onLogout: () => void;
  guestSearchCount: number;
  onMapUpload: (svgContent: string, floor: Floor) => void;
  uploadActivities: UploadActivity[];
  customMapSvgs: {
    ground: string | null;
    first: string | null;
    second: string | null;
  };
  buildings: Building[];
  onAddBuilding: (building: { name: string }) => void;
  onUpdateBuilding: (building: Building) => void;
  onDeleteBuilding: (id: number) => void;
  routeSearches: Record<string, number>;
}

type AdminSection = 'dashboard' | 'campus' | 'buildings' | 'data' | 'analytics';

const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ 
  onLogout, 
  guestSearchCount, 
  onMapUpload, 
  uploadActivities, 
  customMapSvgs,
  buildings,
  onAddBuilding,
  onUpdateBuilding,
  onDeleteBuilding,
  routeSearches
}) => {
  const [activeSection, setActiveSection] = useState<AdminSection>('dashboard');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadingFloor, setUploadingFloor] = useState<Floor | null>(null);
  const [uploadFeedback, setUploadFeedback] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const [isUploadPopoverOpen, setUploadPopoverOpen] = useState(false);
  const uploadCardRef = useRef<HTMLDivElement>(null);
  const [previewFloor, setPreviewFloor] = useState<Floor>('ground');
  
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isTimetableModalOpen, setIsTimetableModalOpen] = useState(false);
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (uploadCardRef.current && !uploadCardRef.current.contains(event.target as Node)) {
            setUploadPopoverOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
        document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleEditClick = (building: Building) => {
    setSelectedBuilding(building);
    setIsTimetableModalOpen(true);
  };
  
  const handleCloseModals = () => {
    setIsAddModalOpen(false);
    setIsTimetableModalOpen(false);
    setSelectedBuilding(null);
  };

  const handleSaveTimetable = (updatedBuilding: Building) => {
    onUpdateBuilding(updatedBuilding);
    handleCloseModals();
  };

  const handleFileUploadClick = (floor: Floor) => {
    setUploadingFloor(floor);
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!uploadingFloor) return;
    const file = event.target.files?.[0];
    if (file && file.type === 'image/svg+xml') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const svgContent = e.target?.result as string;
        onMapUpload(svgContent, uploadingFloor);
        setUploadFeedback({ message: `SVG for ${uploadingFloor.charAt(0).toUpperCase() + uploadingFloor.slice(1)} Floor uploaded successfully!`, type: 'success' });
        setTimeout(() => setUploadFeedback(null), 5000);
      };
      reader.onerror = () => {
        setUploadFeedback({ message: 'Error reading the SVG file.', type: 'error' });
        setTimeout(() => setUploadFeedback(null), 5000);
      };
      reader.readAsText(file);
    } else {
        setUploadFeedback({ message: 'Please select a valid SVG file.', type: 'error' });
        setTimeout(() => setUploadFeedback(null), 5000);
    }
    event.target.value = '';
    setUploadingFloor(null);
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <DashboardSection guestSearchCount={guestSearchCount} uploadActivities={uploadActivities} routeSearches={routeSearches} />;
      case 'buildings':
        return <BuildingsSection />;
      case 'data':
        return <DataManagementSection 
                  buildings={buildings} 
                  onAddBuildingClick={() => setIsAddModalOpen(true)}
                  onEditBuildingClick={handleEditClick}
                  onDeleteBuilding={onDeleteBuilding}
               />;
      case 'analytics':
        return <AnalyticsSection />;
      case 'campus':
        return (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">Manage Campus Map (2D)</h2>
            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/svg+xml" className="hidden" />
            
            {uploadFeedback && (
              <div className={`p-4 mb-2 text-sm rounded-lg transition-opacity duration-300 ${uploadFeedback.type === 'success' ? 'bg-green-100 dark:bg-green-800/30 text-green-700 dark:text-green-300 border border-green-200 dark:border-green-600/50' : 'bg-red-100 dark:bg-red-800/30 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-600/50'}`} role="alert">
                <span className="font-medium">{uploadFeedback.type === 'success' ? 'Success!' : 'Error:'}</span> {uploadFeedback.message}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="relative" ref={uploadCardRef}>
                    <AdminActionCard
                        icon={<UploadIcon className="w-8 h-8 text-violet-500 dark:text-brand-primary" />}
                        title="Upload 2D Layout"
                        description="Upload a custom 2D SVG layout for a specific floor."
                        actionText="Choose Floor..."
                        onActionClick={() => setUploadPopoverOpen(prev => !prev)}
                    />
                    {isUploadPopoverOpen && (
                        <div className="absolute top-full mt-2 w-full bg-white dark:bg-slate-800 rounded-md shadow-lg border border-slate-200 dark:border-slate-700 z-10 p-2 space-y-1 animate-fadeIn">
                            {(['ground', 'first', 'second'] as const).map(floor => (
                                <button
                                    key={floor}
                                    onClick={() => {
                                        handleFileUploadClick(floor);
                                        setUploadPopoverOpen(false);
                                    }}
                                    className="w-full text-left px-4 py-2 text-sm text-slate-700 dark:text-brand-text-secondary hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md transition-colors"
                                >
                                    {floor.charAt(0).toUpperCase() + floor.slice(1)} Floor
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            </div>
            <div className="p-6 bg-white dark:bg-brand-surface rounded-lg shadow-sm border border-slate-200 dark:border-slate-800">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-slate-800 dark:text-brand-text-primary">Current Map Preview:</h3>
                    <div className="bg-slate-100 dark:bg-slate-800/50 p-1 rounded-lg flex items-center space-x-1">
                        {(['ground', 'first', 'second'] as const).map((floor) => {
                            const floorLabel = floor === 'ground' ? 'G' : floor === 'first' ? '1' : '2';
                            return (
                            <button
                                key={floor}
                                onClick={() => setPreviewFloor(floor)}
                                className={`px-3 py-1 text-sm font-semibold rounded-md transition-all duration-200 w-9 ${
                                previewFloor === floor ? 'bg-violet-600 dark:bg-brand-primary text-white shadow' : 'text-slate-600 dark:text-brand-text-secondary hover:bg-black/5 dark:hover:bg-slate-700/50'
                                }`}
                                title={`${floor.charAt(0).toUpperCase() + floor.slice(1)} Floor`}
                            >
                                {floorLabel}
                            </button>
                            )
                        })}
                    </div>
                </div>
                <div className="w-full h-80 bg-slate-200 dark:bg-black rounded-md overflow-hidden border border-slate-200 dark:border-slate-700">
                    <InteractiveMapView width="100%" height="100%">
                    {(() => {
                        const svgContent = customMapSvgs[previewFloor];
                        if (svgContent) {
                        return <g dangerouslySetInnerHTML={{ __html: svgContent }} />;
                        }
                        if (previewFloor === 'ground') {
                        return <CampusMapSVG />;
                        }
                        return (
                        <g>
                            <rect x="0" y="0" width="800" height="600" fill="var(--map-bg)" />
                            <text x="400" y="300" textAnchor="middle" fontFamily="sans-serif" fontSize="20" fill="var(--map-text)">
                            No map uploaded for {previewFloor} floor.
                            </text>
                        </g>
                        );
                    })()}
                    </InteractiveMapView>
                </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-brand-background">
      <aside className="w-64 bg-white dark:bg-brand-surface border-r border-slate-200 dark:border-slate-800 flex flex-col">
        <div className="p-6 border-b border-slate-200 dark:border-slate-800">
          <h1 className="text-xl font-bold text-violet-600 dark:text-brand-primary tracking-tight">Admin Panel</h1>
          <p className="text-sm text-slate-500 dark:text-brand-text-secondary">MapItUP</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <NavItem 
            icon={<DashboardIcon className="w-5 h-5 mr-3" />} 
            label="Dashboard" 
            isActive={activeSection === 'dashboard'} 
            onClick={() => setActiveSection('dashboard')} 
          />
          <NavItem 
            icon={<MapIcon className="w-5 h-5 mr-3" />} 
            label="Campus Map" 
            isActive={activeSection === 'campus'} 
            onClick={() => setActiveSection('campus')} 
          />
           <NavItem 
            icon={<BuildingIcon className="w-5 h-5 mr-3" />} 
            label="Buildings" 
            isActive={activeSection === 'buildings'} 
            onClick={() => setActiveSection('buildings')} 
          />
          <NavItem 
            icon={<DatabaseIcon className="w-5 h-5 mr-3" />} 
            label="Data Management" 
            isActive={activeSection === 'data'} 
            onClick={() => setActiveSection('data')} 
          />
          <NavItem 
            icon={<ChartBarIcon className="w-5 h-5 mr-3" />} 
            label="Analytics" 
            isActive={activeSection === 'analytics'} 
            onClick={() => setActiveSection('analytics')} 
          />
        </nav>
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <button 
            onClick={onLogout}
            className="flex items-center justify-center py-2 px-3 rounded-md text-sm font-medium text-slate-600 dark:text-brand-text-secondary bg-slate-100 dark:bg-slate-800 hover:bg-red-500/10 dark:hover:bg-red-500/20 hover:text-red-500 dark:hover:text-red-400 transition-colors"
          >
            <LogoutIcon className="w-5 h-5 mr-2" />
            Logout
          </button>
          <ThemeSwitcher />
        </div>
      </aside>

      <main className="flex-1 p-10 overflow-y-auto">
        {renderSection()}
      </main>

      {isAddModalOpen && <AddBuildingModal onClose={handleCloseModals} onAdd={onAddBuilding} />}
      {isTimetableModalOpen && selectedBuilding && (
        <TimetableModal 
          building={selectedBuilding}
          onClose={handleCloseModals}
          onSave={handleSaveTimetable}
        />
      )}
    </div>
  );
};

const DashboardSection = ({ guestSearchCount, uploadActivities, routeSearches }: { guestSearchCount: number, uploadActivities: UploadActivity[], routeSearches: Record<string, number> }) => {
    const formatTimeAgo = (timestamp: number) => {
        const now = Date.now();
        const seconds = Math.floor((now - timestamp) / 1000);

        if (seconds < 5) return "just now";
        if (seconds < 60) return `${seconds} second${seconds !== 1 ? 's' : ''} ago`;

        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;

        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;

        const days = Math.floor(hours / 24);
        return `${days} day${days > 1 ? 's' : ''} ago`;
    };

    const popularRoutes = Object.entries(routeSearches)
        .map(([route, count]) => ({ route, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

    const maxSearches = popularRoutes.length > 0 ? Math.max(...popularRoutes.map(r => r.count)) : 1;

    return (
        <div className="animate-fadeIn space-y-8">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">Dashboard Overview</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <StatCard 
                    icon={<UserGroupIcon className="w-8 h-8 text-sky-500" />}
                    title="Guest Searches"
                    value={guestSearchCount.toString()}
                    change="Total routes calculated"
                    changeType="neutral"
                />
                <StatCard 
                    icon={<MapIcon className="w-8 h-8 text-amber-500" />}
                    title="Map Version"
                    value="v0.1"
                    change="Multi-floor support added"
                    changeType="increase"
                />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md border border-slate-200 dark:border-slate-800">
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-brand-text-primary mb-4">Popular Routes</h3>
                    <div className="space-y-4 pt-2">
                        {popularRoutes.length > 0 ? (
                            popularRoutes.map((routeData, index) => (
                                <div key={routeData.route} className="group animate-fadeInUp" style={{ animationDelay: `${index * 100}ms`}}>
                                    <div className="flex justify-between items-center mb-1 text-sm">
                                        <span className="font-medium text-slate-700 dark:text-brand-text-secondary truncate pr-4" title={routeData.route}>
                                            {routeData.route}
                                        </span>
                                        <span className="font-semibold text-slate-800 dark:text-brand-text-primary">
                                            {routeData.count} <span className="text-xs font-normal text-slate-500">searches</span>
                                        </span>
                                    </div>
                                    <div className="w-full bg-slate-200/70 dark:bg-slate-800 rounded-full h-3 shadow-inner">
                                        <div 
                                            className="bg-gradient-to-r from-brand-primary to-brand-accent h-3 rounded-full transition-all duration-500 ease-out"
                                            style={{ width: `${(routeData.count / maxSearches) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="w-full h-64 flex items-center justify-center text-slate-500 dark:text-brand-text-secondary text-center px-4">
                                <p>No route data yet. Perform some searches in the guest view to see popular routes here!</p>
                            </div>
                        )}
                    </div>
                </div>
                <div className="bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md border border-slate-200 dark:border-slate-800">
                    <h3 className="text-lg font-semibold text-slate-800 dark:text-brand-text-primary mb-4">Recent Activity</h3>
                    <ul className="space-y-4">
                        {uploadActivities.length > 0 ? (
                            uploadActivities.map((activity, index) => (
                                <li key={index} className="flex items-center text-sm">
                                    <div className="p-2 bg-blue-100 dark:bg-blue-500/20 rounded-full mr-3">
                                        <UploadIcon className="w-4 h-4 text-blue-600 dark:text-blue-400"/>
                                    </div>
                                    <div>
                                        <p className="text-slate-700 dark:text-brand-text-secondary">
                                            Uploaded 2D map for <span className="font-semibold text-slate-800 dark:text-brand-text-primary">{activity.floor.charAt(0).toUpperCase() + activity.floor.slice(1)} floor</span>
                                        </p>
                                        <p className="text-xs text-slate-500">{formatTimeAgo(activity.timestamp)}</p>
                                    </div>
                                </li>
                            ))
                        ) : (
                            <li className="text-sm text-slate-500 dark:text-brand-text-secondary text-center py-4">
                                No recent activity to show.
                            </li>
                        )}
                    </ul>
                </div>
            </div>
        </div>
    );
};

const BuildingsSection = () => (
    <div className="space-y-6 animate-fadeIn">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">Manage Campus Buildings (3D)</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AdminActionCard
                icon={<UploadIcon className="w-8 h-8 text-violet-500 dark:text-brand-primary" />}
                title="Upload 3D Model"
                description="Upload a GLB/GLTF file for a building to enable 3D view."
                actionText="Upload Model"
                onActionClick={() => alert('Feature to be implemented!')}
            />
        </div>
    </div>
);

const DataManagementSection: React.FC<{
  buildings: Building[];
  onAddBuildingClick: () => void;
  onEditBuildingClick: (building: Building) => void;
  onDeleteBuilding: (id: number) => void;
}> = ({ buildings, onAddBuildingClick, onEditBuildingClick, onDeleteBuilding }) => (
    <div className="animate-fadeIn">
        <div className="flex justify-between items-center mb-6">
             <h2 className="text-3xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">Data Management</h2>
             <button onClick={onAddBuildingClick} className="flex items-center text-sm font-semibold text-white bg-gradient-to-r from-brand-primary to-brand-secondary hover:from-brand-secondary hover:to-brand-primary px-4 py-2 rounded-md transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-brand-primary/40">
                <PlusIcon className="w-5 h-5 mr-2" /> Add New Building
            </button>
        </div>
        <div className="bg-white dark:bg-brand-surface rounded-lg shadow-md border border-slate-200 dark:border-slate-800 overflow-hidden">
            <table className="w-full text-sm text-left text-slate-500 dark:text-slate-400">
                <thead className="text-xs text-slate-700 uppercase bg-slate-50 dark:bg-slate-800 dark:text-slate-400">
                    <tr>
                        <th scope="col" className="px-6 py-3">Building Name</th>
                        <th scope="col" className="px-6 py-3">Last Updated</th>
                        <th scope="col" className="px-6 py-3"><span className="sr-only">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    {buildings.map(building => (
                        <tr key={building.id} className="bg-white dark:bg-brand-surface border-b dark:border-slate-800 hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                            <th scope="row" className="px-6 py-4 font-medium text-slate-900 whitespace-nowrap dark:text-white">{building.name}</th>
                            <td className="px-6 py-4">{building.lastUpdated}</td>
                            <td className="px-6 py-4 text-right space-x-2">
                                <button onClick={() => onEditBuildingClick(building)} className="font-medium text-teal-600 dark:text-brand-accent hover:underline p-1" aria-label={`Edit timetable for ${building.name}`}><EditIcon className="w-5 h-5" /></button>
                                <button onClick={() => onDeleteBuilding(building.id)} className="font-medium text-red-600 dark:text-red-500 hover:underline p-1" aria-label={`Delete ${building.name}`}><TrashIcon className="w-5 h-5" /></button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </div>
);


const AnalyticsSection = () => (
    <div className="animate-fadeIn space-y-8">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-brand-text-primary tracking-tight">Usage Analytics</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md border border-slate-200 dark:border-slate-800">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-brand-text-primary mb-4">Peak Hours</h3>
                {/* Mock Chart */}
                <div className="h-64 flex items-end justify-around p-4 space-x-2">
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '30%' }} title="9am"></div>
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '60%' }} title="11am"></div>
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '95%' }} title="1pm"></div>
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '80%' }} title="3pm"></div>
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '50%' }} title="5pm"></div>
                    <div className="w-1/6 bg-teal-200 dark:bg-brand-accent/50 rounded-t-lg" style={{ height: '20%' }} title="7pm"></div>
                </div>
            </div>
             <div className="bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md border border-slate-200 dark:border-slate-800">
                <h3 className="text-lg font-semibold text-slate-800 dark:text-brand-text-primary mb-4">Device Usage</h3>
                {/* Mock Chart */}
                <div className="h-64 flex items-center justify-center">
                    <div className="w-48 h-48 rounded-full" style={{ background: `conic-gradient(var(--brand-primary) 0% 65%, var(--brand-accent) 65% 90%, var(--brand-light) 90% 100%)`}}>
                        <div className="w-full h-full flex items-center justify-center">
                            <div className="w-24 h-24 bg-white dark:bg-brand-surface rounded-full"></div>
                        </div>
                    </div>
                </div>
                <div className="flex justify-center mt-4 space-x-4 text-xs">
                    <span className="flex items-center"><div className="w-3 h-3 rounded-full bg-brand-primary mr-2"></div>Mobile (65%)</span>
                    <span className="flex items-center"><div className="w-3 h-3 rounded-full bg-brand-accent mr-2"></div>Desktop (25%)</span>
                    <span className="flex items-center"><div className="w-3 h-3 rounded-full bg-brand-light mr-2"></div>Tablet (10%)</span>
                </div>
            </div>
        </div>
    </div>
);


interface StatCardProps {
    icon: React.ReactNode;
    title: string;
    value: string;
    change: string;
    changeType: 'increase' | 'decrease' | 'neutral';
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, change, changeType }) => {
    const changeColor = {
        increase: 'text-green-500 dark:text-green-400',
        decrease: 'text-red-500 dark:text-red-400',
        neutral: 'text-slate-500 dark:text-brand-text-secondary',
    };
    return (
         <div className="bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 flex flex-col border border-slate-200 dark:border-slate-800 transform hover:-translate-y-1 dark:hover:shadow-[0_0_15px_rgba(167,139,250,0.1)]">
            <div className="flex items-start justify-between">
                <div className="flex-shrink-0">
                    <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">{icon}</div>
                </div>
                <div className="text-right">
                    <p className="text-sm font-medium text-slate-500 dark:text-brand-text-secondary truncate">{title}</p>
                    <p className="mt-1 text-3xl font-semibold text-slate-900 dark:text-brand-text-primary">{value}</p>
                </div>
            </div>
            <p className={`mt-4 text-sm ${changeColor[changeType]}`}>
                {change}
            </p>
        </div>
    );
};


interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, isActive, onClick }) => (
  <a
    href="#"
    onClick={(e) => { e.preventDefault(); onClick(); }}
    className={`flex items-center px-4 py-2.5 rounded-md text-sm font-medium transition-colors ${
      isActive
        ? 'bg-violet-100 dark:bg-brand-primary/20 text-violet-600 dark:text-brand-primary'
        : 'text-slate-600 dark:text-brand-text-secondary hover:bg-slate-100 dark:hover:bg-slate-800'
    }`}
  >
    {icon}
    {label}
  </a>
);

interface AdminActionCardProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    actionText: string;
    onActionClick?: () => void;
}

const AdminActionCard: React.FC<AdminActionCardProps> = ({ icon, title, description, actionText, onActionClick }) => (
    <div className="bg-white dark:bg-brand-surface p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 flex flex-col border border-slate-200 dark:border-slate-800 hover:border-violet-300 dark:hover:border-brand-primary/50 transform hover:-translate-y-1 dark:hover:shadow-[0_0_15px_rgba(167,139,250,0.2)]">
        <div className="flex items-center mb-4">
            {icon}
            <h3 className="ml-4 text-lg font-semibold text-slate-800 dark:text-brand-text-primary">{title}</h3>
        </div>
        <p className="text-slate-600 dark:text-brand-text-secondary text-sm flex-grow">{description}</p>
        <button 
            onClick={onActionClick}
            className="mt-6 self-start text-sm font-semibold text-white bg-gradient-to-r from-brand-primary to-brand-secondary hover:from-brand-secondary hover:to-brand-primary px-4 py-2 rounded-md transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-brand-primary/40"
        >
            {actionText}
        </button>
    </div>
);

const AddBuildingModal: React.FC<{
  onClose: () => void;
  onAdd: (building: { name: string }) => void;
}> = ({ onClose, onAdd }) => {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onAdd({ name: name.trim() });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center animate-fadeIn" onClick={onClose}>
      <div className="bg-white dark:bg-brand-surface rounded-lg shadow-2xl w-full max-w-md p-8 m-4 animate-fadeInUp" onClick={e => e.stopPropagation()}>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-brand-text-primary mb-6">Add New Building</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="building-name" className="block text-sm font-medium text-slate-700 dark:text-brand-text-secondary">Building Name</label>
            <input type="text" id="building-name" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full pl-3 py-2 border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-brand-text-primary rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-primary" />
          </div>
          <div className="flex justify-end pt-4 space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-brand-text-secondary bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-md transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-brand-primary hover:bg-brand-secondary rounded-md transition-colors">Add Building</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const TimetableModal: React.FC<{
  building: Building;
  onClose: () => void;
  onSave: (building: Building) => void;
}> = ({ building, onClose, onSave }) => {
  const [timetable, setTimetable] = useState<Timetable>(building.timetable);

  const handleTimetableChange = (day: Day, hourIndex: number, value: string) => {
    const newTimetable = { ...timetable };
    // Ensure that if the input is cleared, it's stored as "Available"
    newTimetable[day][hourIndex] = value.trim() === '' ? 'Available' : value;
    setTimetable(newTimetable);
  };

  const handleSave = () => {
    onSave({ ...building, timetable });
  };

  const days: Day[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
  const hours = Array.from({ length: 14 }, (_, i) => `${8 + i}:00`);

  return (
     <div className="fixed inset-0 bg-black/60 z-50 flex justify-center items-center animate-fadeIn p-4" onClick={onClose}>
      <div className="bg-white dark:bg-brand-surface rounded-lg shadow-2xl w-full max-w-5xl animate-fadeInUp flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
        <div className="p-6">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-brand-text-primary">Edit Timetable: {building.name}</h2>
          <p className="text-sm text-slate-500 dark:text-brand-text-secondary">Schedule from 8:00 AM to 10:00 PM</p>
        </div>
        <div className="overflow-auto px-6 pb-6">
            <table className="w-full text-sm text-left border-separate border-spacing-x-1 border-spacing-y-1">
                <thead className="sticky top-0 z-10">
                    <tr>
                        <th className="p-2 font-semibold text-slate-600 dark:text-brand-text-secondary w-24 bg-white dark:bg-brand-surface">Time</th>
                        {days.map(day => <th key={day} className="p-2 font-semibold text-slate-600 dark:text-brand-text-secondary capitalize bg-white dark:bg-brand-surface text-center">{day}</th>)}
                    </tr>
                </thead>
                <tbody>
                    {hours.map((hour, hourIndex) => (
                        <tr key={hour}>
                            <td className="py-2 px-3 font-mono text-slate-500 dark:text-brand-text-secondary whitespace-nowrap">{hour}</td>
                            {days.map(day => {
                                const currentValue = timetable[day][hourIndex];
                                const isAvailable = !currentValue || currentValue.toLowerCase() === 'available';
                                return (
                                <td key={day} className="align-middle">
                                    <input 
                                      type="text"
                                      value={isAvailable ? '' : currentValue}
                                      onChange={e => handleTimetableChange(day, hourIndex, e.target.value)}
                                      placeholder="-"
                                      className={`w-full text-sm text-center p-2.5 border-none rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-brand-primary
                                        ${isAvailable 
                                            ? 'bg-slate-100 dark:bg-slate-800/60 text-slate-900 dark:text-brand-text-primary placeholder:text-slate-400 dark:placeholder:text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800' 
                                            : 'bg-violet-100 dark:bg-brand-primary/20 text-violet-800 dark:text-brand-light font-semibold'
                                        }`}
                                    />
                                </td>
                            )})}
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
        <div className="flex justify-end p-6">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 dark:text-brand-text-secondary bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-md transition-colors mr-3">Cancel</button>
            <button type="button" onClick={handleSave} className="px-6 py-2 text-sm font-medium text-white bg-brand-primary hover:bg-brand-secondary rounded-md transition-colors">Save Changes</button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardPage;